# Higgsfield Named Motion Presets

Higgsfield has 100+ named motion presets. When using a supported platform preset,
reference it **by exact name** to request its signature effect. These optional VFX
macros do not make Motion preset a required field for free-prompted video work.

For full performance format and segmentation, follow the authoritative
[shared narrative planning](narrative-planning.md):
a **stage** is a dramatic event or state transition, a **shot** is continuous
camera coverage between cuts, and a **generation clip** is one model output.
A shot may span several stages, and a stage may need several shots or clips;
multi-shot generation can also put several shots in one clip. Plan entry state →
action → visible consequence → exit state before deciding cuts or clip durations.
Carry consequences forward, and place effects at story events rather than adding
beats to fill a fixed time envelope.

> **Scope caveat** `[FIELD — 13-project community harvest + live
> preset-catalog pull, both 2026-07-18]`: motion presets are the
> **viral-effects / social product**, not the film grammar. None of the 13
> harvested community film/ad productions used a single motion preset —
> serious film work free-prompts its camera through Cinema Studio /
> Seedance block briefs (`higgsfield-camera.md`,
> `higgsfield-seedance.md`). Separately, the live catalog pull
> showed ~100 unique preset names expanded into ~1,900 per-model variants
> (kling / higgsfield / wan / minimax / seedance families with baked
> params); category weights at pull time skewed to effects/viral/vfx/ugc. Route preset requests here as ever — but don't
> steer a filmmaking request into presets when free-prompted camera language
> is the production-proven path.

**How to use in a prompt:**
```
[Your scene description.] Apply the [Preset Name] preset.
```

---

## QUICK FACTS

*Routing aids only; read the linked sections for full rules.*
- Use catalog preset names exactly; keep scene, setting and effect explicit [→](#how-to-request-a-preset-in-a-prompt).
- Choreography follows visible intent and causal events [→](#intent-over-timestamps).
- Motion references carry timing and movement; state what the reference controls [→](#video-reference-as-primary-method).
- Give each shot a readable primary action and preserve its consequences [→](#one-action-per-shot-rule).
- Diagnose density from required story beats before allocating time [→](#beat-density-diagnostic).
- Motion Control follows the original selection and tool workflow [→](#kling-30-motion-control--when-and-how-to-run-it).
- Verify source quality, mode and motion binding before generation [→](#motion-reference-input-checklist).

## Transformation & Body Effects

| Preset | What it does | Best for |
|--------|-------------|----------|
| **Animalization** | Subject transforms into an animal | Werewolf, shapeshifter, fantasy |
| **Werewolf** | Human-to-werewolf transformation sequence | Horror, fantasy, supernatural |
| **Cyborg** | Subject gains mechanical/cybernetic components | Sci-fi, body augmentation |
| **Turning Metal** | Subject or object transforms into metal | Sci-fi, industrial, transformation |
| **Disintegration** | Subject breaks apart into particles | Dramatic death, magic, sci-fi |
| **Gas Transformation** | Subject dissolves into gas or smoke | Mystery, supernatural, horror |
| **Clone Explosion** | Subject multiplies and explodes outward | Action, surreal, energetic |
| **Monstrosity** | Subject transforms into a monstrous form | Horror, dark fantasy |
| **X-Ray** | Subject shown with visible internal structure | Medical, sci-fi, surreal |
| **Freezing** | Subject or scene freezes into ice | Winter, magic, time-stop |
| **Tattoo Animation** | Tattoos on skin come alive and move | Artistic, body art, fantasy |
| **Hair Style** | Subject's hair rapidly changes style | Fashion, fun, transformation |
| **Luminous Gaze** | Eyes emit powerful glowing light | Supernatural, power awakening |
| **Black Tears** | Subject cries dark/black tears | Emotional horror, dark drama |
| **Head Off** | Subject's head appears separated from body | Surreal, horror, dark humor |
| **Head Explosion** | Subject's head explodes dramatically | Action, horror, surreal |
| **Duplicate** | Subject is duplicated/cloned in frame | Surreal, sci-fi, artistic |
| **Ghoulgao** | Subject transforms into a ghoul | Halloween, horror |

---

## Elemental Effects

| Preset | What it does | Best for |
|--------|-------------|----------|
| **Air Bending** | Subject controls and bends air currents | Fantasy, martial arts, elemental |
| **Water Bending** | Subject controls flowing water | Fantasy, elemental, mystical |
| **Earth Wave** | Ground ripples and waves like water | Earthquake, power, epic |
| **Fire Element** | Fire surrounds or emanates from subject | Action, elemental, power |
| **Water Element** | Water surrounds or flows around subject | Mystical, elemental |
| **Earth Element** | Earth/rock forms around subject | Fantasy, elemental warrior |
| **Air Element** | Air currents visibly swirl around subject | Elemental, windmaster |
| **Firelava** | Fire and lava merge in the scene | Volcanic, epic destruction |
| **Explosion** | Large-scale explosion effect | Action, war, destruction |
| **Building Explosion** | Entire building explodes | Disaster, action blockbuster |
| **Plasma Explosion** | Subject or object explodes in plasma | Sci-fi, energy weapon hit |
| **Atomic** | Nuclear-scale blast and shockwave | Post-apocalyptic, epic |
| **Flame On** | Subject ignites and burns without harm | Superhero, elemental, fantasy |
| **Flame Transition** | Fire sweeps across frame as transition | Action transition, drama |
| **Northern Lights** | Aurora borealis fills the sky | Nature, mystical, atmospheric |
| **Nature Bloom** | Flowers and plants rapidly bloom | Spring, life, time-lapse feel |

---

## Transitions

| Preset | What it does | Best for |
|--------|-------------|----------|
| **Raven Transition** | Dark, dramatic wipe transition | Horror, thriller, intense drama |
| **Splash Transition** | Water splash sweeps across frame | Aquatic, fresh, energetic |
| **Flame Transition** | Fire sweeps across frame | Action, intensity |
| **Melt Transition** | Scene melts away into the next | Surreal, dreamy, artistic |
| **Smoke Transition** | Smoke fills frame then clears to new scene | Mysterious, atmospheric |
| **Seamless Transition** | Clean invisible cut between scenes | Any genre, professional |
| **Jump Transition** | Quick kinetic jump cut | Action, energy |
| **Hole Transition** | A hole appears and expands to new scene | Surreal, portal, sci-fi |
| **Roll Transition** | Frame rolls like a scroll | Artistic, playful |
| **Fly Cam Transition** | Camera flies through space to new scene | Cinematic, epic |
| **Display Transition** | Screen/display device reveals new scene | Tech, modern, meta |
| **Hand Transition** | A hand wipes/sweeps to new scene | Stylized, editorial |
| **Stranger Transition** | Mysterious figure triggers transition | Thriller, mystery |
| **Column Wipe** | Columns of image wipe to reveal new scene | Stylized, editorial |
| **Intermission** | Old-cinema intermission card style | Retro, playful, meta |

---

## Action & Motion Effects

| Preset | What it does | Best for |
|--------|-------------|----------|
| **Fast Sprint** | Subject sprints at superhuman speed | Action, chase, power |
| **Giant Grab** | Enormous hand or creature grabs subject | Horror, monster, scale |
| **I Can Fly** | Subject lifts off and flies | Superhero, fantasy, joy |
| **Hero Flight** | Cinematic superhero-style flight arc | Superhero, action |
| **Train Rush** | High-speed train rushes past | Action, transport, speed |
| **Bullet Time Scene** | Matrix-style frozen moment camera sweep | Action climax, impact |
| **Bullet Time White** | Bullet time with white flash | Action, high contrast |
| **Bullet Time Splash** | Bullet time with liquid splash | Combat, impact |
| **Levitation** | Subject levitates upward | Magic, supernatural, zen |
| **Shadow Smoke** | Subject's shadow takes on smoke quality | Dark, supernatural |
| **Shadow** | Dramatic shadow play in scene | Noir, mystery, drama |
| **Glow Trace** | Moving subject leaves glowing trail | Dance, action, energy |
| **Live Concert** | Concert atmosphere with stage lighting | Music, performance |
| **3D Rotation** | Subject or object rotates in 3D space | Product, logo, artistic |

---

## Surreal / Artistic

| Preset | What it does | Best for |
|--------|-------------|----------|
| **Multiverse** | Scene fractures into parallel versions | Sci-fi, surreal, mind-bending |
| **Wonderland** | Dreamlike Alice-in-Wonderland reality | Fantasy, children, surreal |
| **Portal** | A portal opens to another dimension | Sci-fi, fantasy, travel |
| **Glitch** | Digital glitch artifacts across the image | Cyberpunk, tech, artistic |
| **Point Cloud** | Scene rendered as floating particles | Artistic, sci-fi, abstract |
| **Wireframe** | Subject shown as 3D wireframe | Tech, sci-fi, design |
| **Diamond** | Subject or scene crystallizes to diamond | Fashion, luxury, artistic |
| **Innerlight** | Warm inner glow emanates from subject | Spiritual, emotional, warm |
| **Polygon** | Scene fragments into geometric polygons | Abstract, digital, art |

---

## Nature / Environment

| Preset | What it does | Best for |
|--------|-------------|----------|
| **Earth Zoom Out** | Camera pulls back from earth's surface | Epic reveal, scale, planet |
| **Cotton Cloud** | Soft clouds form and drift through scene | Dreamy, peaceful, sky |
| **Sakura Petals** | Cherry blossom petals fill the air | Japanese aesthetic, romance |
| **Garden Bloom** | Garden bursts into bloom | Spring, life, beauty |
| **Aquarium** | Scene takes on underwater aquarium quality | Nature, peaceful, aquatic |
| **Ice Rose** | Rose or subject freezes in crystalline ice | Winter, beauty, time-stop |
| **Color Rain** | Colorful rain falls through the scene | Artistic, joyful, musical |
| **Glowing Fish** | Bioluminescent fish swim through scene | Underwater, mystical |
| **Bubbles** | Bubbles float upward through the scene | Dreamy, underwater, child-like |

---

## Horror / Dark

| Preset | What it does | Best for |
|--------|-------------|----------|
| **Horror Face** | Subject's face takes on horror distortion | Horror, psychological, jump scare |
| **Spiders from Mouth** | Spiders pour from subject's mouth | Body horror, extreme horror |
| **Storm Creature** | A creature emerges from a storm | Horror, monster reveal |
| **Sand Worm** | Giant sandworm erupts from ground | Sci-fi horror, Dune-style |

---

## Social / Fun

| Preset | What it does | Best for |
|--------|-------------|----------|
| **Money Rain** | Cash rains down from above | Celebration, success, hip-hop |
| **Group Photo** | Scene freezes in a group photo pose | Comedy, social, fun |
| **Firework** | Fireworks burst in the sky/scene | Celebration, new year, joy |
| **Starship Troopers** | Sci-fi military action aesthetic | Sci-fi action, parody |
| **Thunder God** | Subject wields thunder/lightning power | Fantasy, power, epic |
| **Objects Around** | Objects orbit around the subject | Cartoon, playful, magic |
| **Balloon** | Balloons fill the scene | Party, joyful, celebration |
| **Saint Glow** | Halo and saintly glow around subject | Spiritual, ironic, artistic |

---

## How to Request a Preset in a Prompt

```
A woman stands at the edge of a cliff at sunset, hair flowing in the wind.
She raises her hands slowly as energy builds around her.
Camera: Crane Up revealing the ocean below.
Style: Cinematic, golden hour, 16:9.
Apply the Plasma Explosion preset at the moment her hands reach full extension.
```

```
Two fighters face each other in a rain-soaked alley.
Camera: Bullet Time as the first punch lands.
Style: Anamorphic, desaturated, high contrast.
Apply the Flame Transition preset to cut to the next scene.
```

---

> **Negative constraints:** For motion/VFX artifacts (preset not visible, VFX looks cartoonish,
> jittery motion) and their prevention phrases, see `negative-constraints.md` —
> Body/Motion Artifacts and Temporal/Consistency Artifacts sections.

---

## Intent-First Choreography (Cinema Studio 3.0 / Seedance 2.0 Best Practices)

These principles apply to Cinema Studio 3.0's generation engine (Business/Team plan only) and complement the motion preset library above.

### Intent over Timestamps

Describe **INTENT, ACTION and CONSEQUENCE** as a full causal chain: preparation,
contact or miss, object/opponent response, subject follow-through and inherited result.
Avoid unsupported frame-by-frame precision; interpolation does not replace writing the
visible process. The short examples below illustrate compilation, not the full master brief.

**Wrong:** `At 0s: character raises right arm. At 1s: arm reaches 45 degrees. At 2s: arm fully extended. At 3s: energy ball forms.`

**Right:** `The character raises her arm slowly, energy gathering in her palm until it erupts in a blinding flash. Sparks scatter across the floor.`

### @Video Reference as Primary Method

When an available action reference matches the intended choreography, this optional
motion-reference workflow can improve adherence:

1. Upload a reference clip showing the movement you want
2. For a short platform submission, summarize the inherited action in 1–3 sentences; retain the full causal performance in the master brief
3. Add degree adverbs (`violently`, `gracefully`, `explosively`) and physics consequences (`dust erupts`, `sparks fly`)
4. Tell the model to reference the clip

```
Reference @Video1 for movement choreography.
A swordsman draws his blade explosively, cutting through three bamboo stalks in rapid succession.
Stalks topple, leaves scatter, blade gleams in the sunlight.
```

> **Capability boundary:** For what `@Video` reference reads reliably vs. less reliably
> across world / texture / camera character / production feel — and what it can't do at
> all — see `higgsfield-camera.md` § Video Reference — What It Reads, and What
> It Can't. Use this method when suitable footage exists; text-only choreography remains
> supported and must retain the intended action and response.

### One Action Per Shot Rule

For text-only action (no video reference), keep one **primary causal action unit**
legible at a time. Its setup, contact, response, and recovery can remain in one
shot. Split independent actions when clarity, a new information event, or a
model limit requires it; a new motion verb or narrative stage does not by itself
require a cut. Do not collapse a dense chain into an undifferentiated sentence:

**Too compressed as a complete performance brief:** `She jumps over the wall, rolls on landing, draws her weapon, and fires three shots while running.` Expand the causal transitions and results; this sequence can remain in one shot if readable.

**One possible breakdown (separate Cinema Studio 3.0 shots, not a required count):**
- Shot 1: `She leaps over the wall, coat flaring. Landing hard, she rolls forward.`
- Shot 2: `Rising from the roll, she draws her weapon in one fluid motion.`
- Shot 3: `Running at full sprint, she fires three shots. Muzzle flash lights up the alley.`

### Beat Density Diagnostic

If output is blurry, jittery, or morphing, check whether **too many actions are
packed into too short a duration**. Density is a diagnostic, not a shot-count
formula or a guaranteed model capacity.

The older **1–2 distinct action beats every 5 seconds** guideline is an optional
starting heuristic for simple text-only motion. Four or more independent actions
in that window can be a warning sign; complexity, contact, spatial changes,
performance, and reference quality matter more than the count. A quiet reaction
may need more time than several linked gestures.

| Illustrative action window | Heuristic beat range (not a maximum or target) | Example |
|----------|-----------|---------|
| 3–5s | 1–2 | Jump + land |
| 5–8s | 2–3 | Jump + land + draw weapon |
| 8–12s | 3–5 | Jump + land + draw + fire + take cover |
| 12–15s | 4–6 | Action sequence; use multi-shot only where coverage needs it |

**Fix:** Simplify redundant action, allow more time within the model's supported
range, or split at a causal turn or state handoff with explicit continuity. The
table does not prescribe equal lengths, a cut per beat, or 15s clips. A stage can
continue within a shot; a shot can continue across supported generation clips.
For example, Seedance 2.0 requires **4–15s per generation**: trim a shorter edit
beat from a legal clip or plan connected clips for a longer event. Motion
Control's reference-input limits below remain separate platform constraints.

---

## Related skills
- `higgsfield-camera` — Camera controls (combine with motion presets)
- `higgsfield-style` — Visual styles (pair with motion effects)
- `higgsfield-mixed-media` — Artistic preset overlays (different from motion presets)
- `higgsfield-recipes` — Genre templates referencing specific presets
- `template-*.md` — Annotated templates showing preset usage in context

---

## Kling 3.0 Motion Control — When and How to Run It

**Important:** This is NOT a named motion preset. Everything above in this
sub-skill is the VFX preset library — Explosion, Werewolf, Air Bending, and so
on — where the preset name triggers a pre-built effect. Kling 3.0 Motion Control
is a different system entirely: a reference-video motion transfer workflow. You
upload a character image plus a short clip of the motion you want, and the model
transfers that motion onto the character. The prompt describes the world around
the motion — not the motion itself.

### When to Choose Motion Control

Reach for Motion Control when the generation needs directed, repeatable motion
rather than a loose interpretation. Typical cases: dance choreography, sports or
athletic beats, acting or reaction beats, precise gestures for a talking head,
and transferring the same motion pattern across different characters (e.g., one
captured performance applied to multiple hero images). It's also useful as a
scene prototyping step before a heavier Kling 3.0 assembly — you can lock the
motion first, then build the surrounding scene around it.

### The 8-Step Higgsfield Workflow

Run Motion Control through the Higgsfield UI in this order:

1. **Open the Video tab** in Higgsfield.
2. **Choose Kling Motion Control 3.0** from the model selector.
3. **Upload the motion reference video** — the short clip carrying the
   performance you want transferred.
4. **Upload the character image** — face and body should both be readable; this
   is what the motion gets mapped onto.
5. **Pick the output resolution** — 720p for faster iteration, 1080p for final
   delivery.
6. **Set the Scene source** — decide whether the environment should come from
   the motion video's background or from the character image's background.
7. **Open Advanced Settings** — describe the lighting, atmosphere, and
   background treatment in the prompt field here, and select the orientation
   mode (Image Orientation for camera-driven shots with a mostly static body;
   Video Orientation for full-body movement like dance or action).
8. **Generate** — review the result and iterate on the reference clip first if
   the motion reads wrong, and on the prompt second if the scene reads wrong.

---

## Motion Reference Input Checklist

Input quality determines output quality. If the reference clip is noisy, the
transfer will be noisy — no amount of prompt refinement fixes a bad source.
Before clicking Generate, confirm the reference clip against this pre-flight
checklist:

- [ ] **One clear subject in frame.** Multi-person clips confuse the motion
      extraction; crop or trim to a single performer.
- [ ] **Head and body both visible.** If either is cut off, the motion transfer
      loses the connection between facial performance and body motion.
- [ ] **Real human motion.** Stylized animation, rotoscoped footage, and heavily
      filtered clips transfer unreliably. Natural performance reads best.
- [ ] **No cuts, dissolves, or hard camera transitions.** The reference must be
      one continuous shot — any cut inside the clip will show up as a jump or
      snap in the generated output.
- [ ] **Avoid very fast actions.** Movement that reads as a blur in the source
      will fail to transfer cleanly. Slow-moderate speed performs best.
- [ ] **Clip duration 3–30 seconds.** Below 3s there isn't enough motion data;
      above 30s is outside Motion Control's supported range.

**Rule of thumb:** if you'd struggle to describe what's happening frame-by-frame
in the reference clip, the model will too. Trim, re-shoot, or re-select the
reference before burning credits on a generation that was always going to fail.

### Binding modes, motion source, and the shortfall diagnostic

A few controls and one diagnostic round out the Motion Control workflow:

- **Motion source — uploaded clip OR motion library.** The motion can come
  from your own uploaded reference clip *or* from Higgsfield's built-in motion
  library. The library is the faster path when you want a known-good
  performance (a dance, a sports beat) without sourcing your own footage.
- **Matches Video vs Matches Image.** The transfer binds the result either to
  the motion video or to the character image. *Matches Video* tracks the
  reference clip's full-body movement and timing; *Matches Image* keeps the
  result anchored to the character image (better for camera-driven shots where
  the body stays mostly static). This is the same axis as the
  Image-Orientation / Video-Orientation choice in step 7 of the workflow —
  pick the one that matches whether the body or the camera is doing the moving.
- **Element binding (Matches Video only).** Binding individual elements of the
  performance is available only in *Matches Video* mode. If you need element-
  level binding, you must be in Matches Video.
- **Close-up face input + emotional transitions.** A close-up face input
  carries emotional transitions well — reach for it when the beat is an acting
  or reaction moment rather than full-body motion.
- **The shortfall diagnostic.** If the **output is suddenly shorter than the
  source clip**, the motion is usually **too fast or too complex** for a clean
  continuous transfer. Slow the reference, simplify the action, or re-trim
  before regenerating — a shorter-than-source output is the model telling you
  the input exceeded what it can transfer cleanly.
