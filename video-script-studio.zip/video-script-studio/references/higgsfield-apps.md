# Higgsfield Apps — One-Click Workflows

For a video deliverable, carry its goal, references and required start/end states from [shared director planning](narrative-planning.md) into app selection and output review. Use only controls the selected app exposes; one-click apps may not accept a detailed stage plan. Where required events or timing exceed those controls, use the routed model workflow. All image-only and one-click workflows below remain available.

Apps are pre-built workflows on Higgsfield that combine model + prompt + settings
into a single-click experience. No prompt writing needed — just upload your input.

---

## Top Apps by Use Case

### Content Creator / Social Media
| App | What it does | Input needed |
|-----|-------------|--------------|
| **AI Influencer Studio** | Create a consistent AI character for social content | Character reference image |
| **Vibe Motion** | Chat-based video generation with motion | Text description |
| **Transitions** | Seamless transition between any two shots | Two images |
| **Shots** | Multiple cinematic angles of one subject | Single image |
| **Zooms** | Dramatic zoom effects on images | Single image |
| **Style Snap** | Apply a visual style to any image | Image + style reference |
| **Chameleon** | Match color/style of one image to another | Two images |

### Character & Face
| App | What it does | Input needed |
|-----|-------------|--------------|
| **Face Swap** | Swap face onto another image | Face image + target image |
| **Video Face Swap** | Swap face in a video | Face image + target video |
| **Recast** | Swap character in any video | Character reference + video |
| **Character Swap 2.0** | Replace character entirely | Character reference + video |
| **Skin Enhancer** | Natural skin texture enhancement | Portrait image |
| **Angles 2.0** | Generate any camera angle from one image | Single image |

### Lifestyle & Fun
| App | What it does | Input needed |
|-----|-------------|--------------|
| **Behind the Scenes** | Add BTS filming aesthetic to any video | Video |
| **Urban Cuts** | Street photography / urban aesthetic | Image or video |
| **AI Stylist** | Try different outfits on a character | Portrait + outfit description |
| **Outfit Swap** | Replace clothing in image/video | Image + clothing reference |
| **Outfit Shot** | Fashion lookbook from a clothing item | Clothing image |
| **Japanese Show** | Japanese variety show aesthetic | Image or video |
| **Rap God** | Rap video aesthetic and styling | Portrait image |
| **Mugshot** | Classic mugshot style portrait | Portrait image |
| **Renaissance** | Classical Renaissance painting portrait | Portrait image |
| **Comic Book** | Comic book style transformation | Image |

### Animation & Effects
| App | What it does | Input needed |
|-----|-------------|--------------|
| **3D Render** | Render image in 3D style | Image |
| **3D Figure** | Convert to 3D figurine/toy | Image |
| **3D Rotation** | 360 degree rotation of subject | Image |
| **Bullet Time Scene** | Matrix-style frozen moment | Image |
| **Sketch-to-Real** | Turn sketch into realistic image/video | Sketch image |
| **Pixel Game** | Pixel art / retro game aesthetic | Image |
| **GTAI** | GTA-style game aesthetic | Image |
| **Melting Doodle** | Subject melts into doodle | Image |
| **Paint App** | Convert to painted artwork | Image |

### Audio / Lipsync
| App | What it does | Input needed |
|-----|-------------|--------------|
| **Lipsync Studio** | Add speech to any face | Portrait/video + audio |
| **Talking Avatar** | Create talking head from image | Portrait + audio/text |
| **ASMR Add-On** | Add ASMR audio to video | Video |
| **ASMR Classic** | ASMR-style content creation | Image or video |
| **ASMR Host** | Talking ASMR presenter | Portrait |

---

## When to Use Apps vs. Manual Prompting

**Use Apps when:**
- You want fast, one-click output without writing a prompt
- The task is well-defined (face swap, product shot, style transfer)
- You're iterating quickly on social content
- The App is purpose-built for exactly your use case

**Use manual prompts when:**
- You need precise control over every element
- The scene is complex or multi-beat
- You're building a longer narrative sequence
- No App covers your specific creative vision

---

## Cinema Studio

Cinema Studio is Higgsfield's professional filmmaking environment — a full production
workflow tool for creating longer, multi-shot cinematic content.

**Best for:**
- Short films and branded content
- Multi-scene sequences with consistent characters
- Professional-grade output beyond single clips

**Workflow:**
1. Define your scene with storyboard or text description
2. Generate key frames with Soul 2.0 or Nano Banana
3. Animate with Kling 2.6/3.0 or Sora 2
4. Chain shots in Cinema Studio timeline
5. Add audio with Kling 3.0 or Lipsync Studio

---

## Related skills
- `higgsfield-cinema` — Cinema Studio for multi-shot sequences
- `higgsfield-models` — Model selection for manual prompting
- `higgsfield-pipeline` — Full production pipelines using Apps as stages
- `higgsfield-assist` — Higgsfield Assist copilot for in-platform guidance
