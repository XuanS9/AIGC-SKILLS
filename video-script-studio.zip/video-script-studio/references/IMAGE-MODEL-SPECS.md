# Model Specs

**Snapshot: 2026-08-01**. Verify current parameters against a user-provided current schema before production.

| Model | id (aliases) | Duration | Resolutions | Modes | Aspect ratios | Media roles | Constraints |
|-------|--------------|----------|-------------|-------|---------------|-------------|-------------|
| AutoSprite Animation | autosprite | — | — | — | — | medias: image | — |
| Bytedance Image Upscale | bytedance_image_upscale | — | 2k, 4k | — | — | medias: image_references | — |
| Cinema Studio Image 2.5 | cinematic_studio_2_5 | — | 1k, 2k, 4k | — | 1:1, 3:2, 2:3, 4:3, 3:4, 4:5, 5:4, 16:9, 9:16, 21:9 | medias: image | — |
| FLUX.2 | flux_2 | — | 1k, 2k | — | 1:1, 4:3, 3:4, 16:9, 9:16 | medias: image_references | — |
| Flux Kontext | flux_kontext | — | — | — | 1:1, 4:3, 3:4, 16:9, 9:16 | medias: image_references | — |
| GPT Image 2 | gpt_image_2 | — | 1k, 2k, 4k | — | 1:1, 4:3, 3:4, 16:9, 9:16, 3:2, 2:3 | medias: image | — |
| Grok Image | grok_image | — | 1k, 2k | std, quality | 1:1, auto, 1:2, 2:1, 3:2, 2:3, 4:3, 3:4, 16:9, 9:16 | medias: image_references | — |
| Auto | image_auto | — | — | — | 1:1, 4:3, 3:4, 16:9, 9:16 | medias: image | — |
| Image Background Remover | image_background_remover | — | — | — | — | medias: image_references | — |
| Kling O1 Image | kling_omni_image | — | 1k, 2k | — | 1:1, auto, 16:9, 9:16, 4:3, 3:4, 3:2, 2:3, 21:9 | medias: image_references | — |
| Nano Banana | nano_banana | — | — | — | 1:1, 3:2, 2:3, 4:3, 3:4, 4:5, 5:4, 9:16, 16:9, 21:9 | medias: image_references | — |
| Nano Banana 2 | nano_banana_2 | — | 1k, 2k, 4k | — | 1:1, 3:2, 2:3, 4:3, 3:4, 4:5, 5:4, 9:16, 16:9, 21:9 | medias: image | — |
| Nano Banana 2 Lite | nano_banana_2_lite | — | 1k | — | auto, 1:1, 3:2, 2:3, 4:3, 3:4, 4:5, 5:4, 9:16, 16:9, 21:9 | medias: image_references | — |
| Nano Banana Pro | nano_banana_2_shots | — | — | — | auto, 1:1, 3:2, 2:3, 4:3, 3:4, 4:5, 5:4, 9:16, 16:9, 21:9 | medias: image_references | — |
| Nano Banana Pro | nano_banana_pro | — | 1k, 2k, 4k | — | 1:1, 3:2, 2:3, 4:3, 3:4, 4:5, 5:4, 9:16, 16:9, 21:9 | medias: image | — |
| OpenAI Hazel | openai_hazel | — | — | — | 1:1, 3:2, 2:3, auto | medias: image_references | — |
| Outpaint | outpaint | — | — | — | auto, 1:1, 3:2, 2:3, 4:3, 3:4, 4:5, 5:4, 9:16, 16:9, 21:9 | medias: image_references | — |
| Recraft V4.1 | recraft_v4_1 (recraft-v4-1) | — | 1k, 2k | — | 1:1, 3:4, 4:3, 4:5, 5:4, 3:2, 2:3, 16:9, 9:16 | — | — |
| Seedream 4.5 | seedream_v4_5 | — | — | — | 1:1, 4:3, 16:9, 3:2, 21:9, 3:4, 9:16, 2:3 | medias: image_references | — |
| Seedream 5.0 Lite | seedream_v5_lite | — | — | — | 1:1, 4:3, 3:4, 16:9, 9:16, 21:9 | medias: image_references | — |
| Seedream 5.0 Pro | seedream_v5_pro | — | 1k, 1.5k, 2k | — | 1:1, 4:3, 3:4, 16:9, 9:16, 3:2, 2:3, 21:9 | medias: image_references | — |
| Higgsfield Soul 2.0 | soul_2 | — | — | — | 1:1, 16:9, 9:16, 4:3, 3:4, 3:2, 2:3 | medias: image | — |
| Soul Cast | soul_cast | — | — | — | 16:9 | — | — |
| Soul Cinema | soul_cinematic | — | — | — | 1:1, 4:3, 3:4, 16:9, 9:16, 3:2, 2:3, 21:9 | medias: image | — |
| Soul Location | soul_location | — | — | — | 1:1, 4:3, 3:4, 16:9, 9:16, 3:2, 2:3, 21:9, 9:21 | — | — |
| Higgsfield Soul 2.0 | soul_v2 | — | — | — | 1:1, 16:9, 9:16, 4:3, 3:4, 3:2, 2:3 | medias: image | — |
| Topaz | topaz_image | — | — | — | — | medias: image_references | — |
| Topaz | topaz_image_generative | — | — | — | — | medias: image_references | — |
| Z Image | z_image | — | — | — | 1:1, 4:3, 3:4, 16:9, 9:16 | — | — |

Full per-model parameter schemas live in `image-model-specs.json` / `image-model-specs.json`.
