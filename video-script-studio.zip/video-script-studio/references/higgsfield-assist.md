# Higgsfield Assist + Credit Optimization

For video budgets, use the actual model calls and durations derived from [shared director planning](narrative-planning.md), including variants, retries and edits. Narrative stages do not directly equal billable generations. Preserve the pricing verification, Assist and optimization workflows below; carry confirmed story and end-state requirements through any cost-saving recommendation.

---

## Higgsfield Assist (GPT-5 Powered Copilot)

**Location:** higgsfield.ai/chat

Higgsfield Assist is a GPT-5 powered creative copilot built directly into the platform.
It's separate from Claude — it lives inside Higgsfield's interface and is trained specifically
on Higgsfield's tools, workflows, and generation patterns.

### What Assist Can Do

- Generate image prompts optimized for the Soul model
- Generate prompts for viral videos in specific styles
- Navigate the platform — recommend which tool to use for a goal
- Recommend the right effects, apps, or presets for your use case
- Answer questions about features and capabilities
- Give feedback on scripts, prompts, or creative concepts
- Suggest fresh ideas when you're blocked
- Help with storyboard planning

### How to Use Assist

1. Click **"Assistant"** in the top Higgsfield header
2. Select the GPT-5 model
3. Ask anything — examples:
   - "Generate a Soul image prompt in the style of a Helmut Newton editorial"
   - "What's the best workflow to create a 30-second branded video with consistent characters?"
   - "Which camera preset works best for a car chase sequence?"
   - "Help me write a prompt for a product video for a skincare brand, sophisticated tone"
4. Copy the generated prompt → paste into the relevant feature

### When to Use Assist vs Claude with This Skill

| Use Assist for | Use this Claude skill for |
|----------------|--------------------------|
| Quick prompt generation within the platform | Building complex multi-shot workflows |
| Platform navigation questions | Structuring long-form projects |
| Viral/trend suggestions (platform-current) | Systematic MCSLA prompt construction |
| Real-time platform feature questions | Genre recipe templates and troubleshooting |
| Rapid iteration inside the Higgsfield UI | Understanding the underlying principles |

**Best workflow:** Use this Claude skill to plan and structure → use Higgsfield Assist
for final in-platform prompt refinement and quick generation.

### Coming Features in Assist
- Generate content (Image, Video, Canvas) directly inside chat
- Upload and analyze media files
- Large file analysis
- Storyboard builder from ideas

---

## Credit Optimization Guide

### Understanding Credits

| Plan | Monthly credits | Cost | Best for |
|------|----------------|------|----------|
| Free | 25 | $0 | Testing only |
| Basic | 150 | $6/mo (annual) | Hobby / light use |
| Pro | 700 | $27/mo (annual) | Regular creators |
| Ultimate | 1,500 | $55/mo (annual) | Daily production |

**Commercial rights:** Basic and above.  
**Watermarks:** Free tier only.  
**Priority processing:** Pro and above.

> Plan names, prices, and credit allowances above are hand-maintained and not
> verifiable from the API catalog (last reviewed 2026-07-06, not re-verified
> against the live UI) — check higgsfield.ai/pricing before quoting them.

### Credit Cost Tiers (Approximate)

*Model roster reviewed against the 2026-07-05 catalog snapshot; tier placements are hand-maintained — verify live before quoting.*

**Low cost:** Seedance 2.0 Fast / Mini, standard image generation, Nano Banana 2 Lite
**Medium cost:** Kling 2.6 (legacy), Kling 3.0 Turbo, Wan 2.5/2.6/2.7, Minimax Hailuo 2.3, standard I2V
**High cost:** Kling 3.0 (pro/4K modes), Seedance 2.0 at 1080p/4K, Veo 3 / 3.1, Cinema Studio
**Apps:** Vary widely — one-click apps are generally efficient

> "Seedance Pro" is a legacy UI label — not in the API catalog (2026-07-05);
> its budget slot is now Seedance 2.0 Fast / Mini. Sora 2 is UI-only (confirmed in the UI 2026-07-06) — not in
> the API catalog as of 2026-07-05; verify in the live UI before recommending.

### Estimate From the Planned Generations

For multi-shot work, multiply the verified per-generation cost by the planned
calls, including reference images, drafts, final-resolution takes and edits.
State the retry allowance separately and label it as a planning assumption.
Use the actual model, duration, resolution and mode for each call; a narrative
stage may require several calls. See `higgsfield-stack.md` for cost
preflight and `higgsfield-troubleshoot.md` for attempt budgets.

### The 5 Most Common Credit Waste Patterns

**1. Generating video before perfecting the image**
The single biggest waste. If your Hero Frame (base image) isn't right, every
animated version will be wrong too.
**Fix:** Spend extra time on image generation (low cost) → animate once (higher cost)

**2. Long prompts that fight each other**
Over-specified prompts create conflicting instructions, forcing multiple regenerations.
**Fix:** Under-specialize on elements you don't care about. Specify only what matters.

**3. Changing multiple variables between generations**
If you change the prompt, the model, AND the camera in one go, you can't learn what fixed what.
**Fix:** Change one thing at a time. Systematic iteration is faster than random retries.

**4. Using premium tiers (Kling 3.0 pro/4K, Seedance 2.0 4K, Veo 3.1) for simple shots**
Premium models for simple single-character, single-camera shots.
**Fix:** Reserve premium models for scenes that genuinely need their capabilities.
Kling 3.0 Turbo or Kling 2.6 (legacy) handles most character drama at lower cost —
and on Kling 3.0, `sound: off` gives a silent video at lower credits (per the
live spec). Seedance has the same switch (`generate_audio: false`).

**5. Not using Apps for tasks Apps are built for**
Face swap, product placement, style transfer — doing these manually via prompt
takes more credits than the App designed for that task.
**Fix:** Check the Apps library first. If an App covers your use case, use it.

---

### The Hero Frame Efficiency Method

This is the single highest-leverage credit optimization technique:

```
Step 1: Generate 5–10 image variations (very low credit cost)
         → Find the one that's closest to your vision
Step 2: Refine that one image with inpainting/editing (low cost)
         → Get it exactly right
Step 3: Animate ONCE from the perfect Hero Frame (medium-high cost)
         → First animation attempt is already working with a strong foundation
```

**Result:** You spend more on cheap image credits, far less on expensive video credits.
The credit math almost always favors this approach.

---

### Model Selection by Budget Scenario

**Tight budget (Basic plan — 150 credits):**
- Primary model: Seedance 2.0 Fast / Mini (fast, low cost; the old "Seedance
  Pro" is a legacy UI label — not in the API catalog)
- Character shots: Kling 3.0 Turbo (or legacy Kling 2.6) only when quality requires it
- Avoid: Kling 3.0 pro/4K modes, Seedance 2.0 at 1080p/4K, Veo 3 / 3.1
- Strategy: Use Apps heavily — they're credit-efficient for their use cases

**Mid budget (Pro plan — 700 credits):**
- Primary models: Kling 3.0 Turbo, Kling 2.6 (legacy), Wan 2.5/2.7, Minimax Hailuo 2.3
- Reserve Kling 3.0 (pro/4K) / Seedance 2.0 4K for hero shots only
  (Sora 2 is UI-only, confirmed present in the UI 2026-07-06 — not in the API catalog; UI
  live UI before recommending it)
- Use Cinema Studio for your two or three most important scenes
- Strategy: Iterate in image first, commit in video second

**High volume (Ultimate — 1,500 credits):**
- Full access to all models
- Cinema Studio as primary workflow for quality content
- Audio is no longer a one-model feature — Seedance 2.0 / 2.0 Mini / 1.5 Pro
  generate native audio (`generate_audio`, default on for 2.0), Kling 3.0 and
  2.6 have a `sound` switch, Veo 3.1 Lite has `generate_audio`. Pick by scene
  fit, then toggle audio — don't pick the model for the audio.
- Strategy: Invest in Moodboard + Soul ID upfront to avoid style drift

---

### Platform Efficiency Tips

**Use presets before writing from scratch**
Higgsfield's presets (visual styles, motion presets, Cinema Studio genres) encode
a lot of quality that's hard to replicate with text alone. Always start with a
preset as a base, then customize.

**Check the Community gallery before generating**
Before burning credits on a new style or effect you haven't tried, find a community
example that uses it. See what actually works before committing.

**Use Assist for quick decisions**
"Should I use Kling 3.0 or Seedance 2.0 for this?" → ask Assist in 5 seconds rather
than generating two test clips.

**Save successful prompts**
When a generation works well, save the complete prompt immediately. Higgsfield
doesn't have a native prompt library — you need your own. A simple text file
organized by genre works well.

**Chain Apps with video for social content**
Generate a base clip with Kling 2.6, then feed it through an App (Transitions,
Style Snap, Urban Cuts) for the final social-ready version. Two steps, total cost
is still lower than generating a "perfect" clip from scratch.

**Batch similar shots together**
If you're using the same Soul ID character in 5 different scenes, generate them in
the same session. The Hero Frame warm-up time is essentially zero if you're
using the same Reference Anchor.

---

### The Platform Learning Path (Credit-Efficient)

**Week 1 — Image foundation (Basic plan)**
- Master Soul 2.0 + Nano Banana Pro for image generation
- Build your first Soul ID character
- Create a Moodboard for your project
- Target: consistently generating images you're proud of

**Week 2 — Simple video (Basic plan)**
- I2V with Kling 2.6, single camera control, one scene type
- Target: one good 5-second clip you'd actually use

**Week 3 — Cinema Studio (Pro plan)**
- One Cinema Studio project, 3–5 shots
- Learn the Hero Frame + Reference Anchor workflow
- Target: a 15–20 second sequence with consistent character

**Week 4+ — Full production (Pro or Ultimate)**
- Mix Cinema Studio with Apps for efficiency
- Add Moodboard + Soul ID for consistent series content
- Use Higgsfield Assist for rapid iteration

---

## Related skills
- `higgsfield-models` — Detailed model comparison beyond what Assist provides
- `higgsfield-prompt` — MCSLA formula for structured prompt building
- `higgsfield-apps` — Apps Assist can recommend
- `higgsfield-pipeline` — Full production workflows
